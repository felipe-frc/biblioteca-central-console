﻿using Biblioteca.Domain.Entities;
using Biblioteca.Web.Data;
using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Web.Controllers
{
    public class UsuariosController : Controller
    {
        private readonly BibliotecaDbContext _context;

        public UsuariosController(BibliotecaDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var usuarios = _context.Usuarios.ToList();
            return View(usuarios);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(string nome, string email)
        {
            var usuario = new Usuario(nome, email);

            _context.Usuarios.Add(usuario);
            _context.SaveChanges();

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int id)
        {
            var usuario = _context.Usuarios.FirstOrDefault(u => u.Id == id);

            if (usuario is null)
                return NotFound();

            return View(usuario);
        }

        [HttpPost]
        public IActionResult Edit(int id, string nome, string email)
        {
            var usuario = _context.Usuarios.FirstOrDefault(u => u.Id == id);

            if (usuario is null)
                return NotFound();

            usuario.AtualizarDados(nome, email);

            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int id)
        {
            var usuario = _context.Usuarios.FirstOrDefault(u => u.Id == id);

            if (usuario is null)
                return NotFound();

            bool temEmprestimoAtivo = _context.Emprestimos
                .Any(e => e.Usuario.Id == id && e.DataDevolucao == null);

            ViewBag.TemEmprestimoAtivo = temEmprestimoAtivo;

            return View(usuario);
        }

        [HttpPost]
        public IActionResult DeleteConfirmed(int id)
        {
            var usuario = _context.Usuarios.FirstOrDefault(u => u.Id == id);

            if (usuario is null)
                return NotFound();

            bool temEmprestimoAtivo = _context.Emprestimos
                .Any(e => e.Usuario.Id == id && e.DataDevolucao == null);

            if (temEmprestimoAtivo)
            {
                TempData["Erro"] = "Não é possível excluir este usuário porque existe empréstimo ativo.";
                return RedirectToAction(nameof(Index));
            }

            _context.Usuarios.Remove(usuario);
            _context.SaveChanges();

            TempData["Sucesso"] = "Usuário excluído com sucesso!";
            return RedirectToAction(nameof(Index));
        }
    }
}